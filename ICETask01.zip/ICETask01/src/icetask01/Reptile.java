/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask01;

/**
 *
 * @author lab_services_student
 */
public class Reptile extends Animal{
    
    //variables
    double bloodTemp;
    
    //getters and setters
    public double getBloodTemp()
    {
        return bloodTemp;
    }
    
    public void setBllodTemp(double bloodTemp)
    {
        this.bloodTemp = bloodTemp;
    }
    
    public Reptile(int IDtag, String species, double bloodTemp)
    {
        super(IDtag, species);
        this.bloodTemp = bloodTemp;
    }
    
    @Override
    public int getIDtag() {
        return IDtag;
    }

    @Override
    public void setIDtag(int IDtag) {
        this.IDtag = IDtag;
    }

    @Override
    public String getSpecies() {
        return species;
    }

    @Override
    public void setSpecies(String species) {
        this.species = species;
    }
}
