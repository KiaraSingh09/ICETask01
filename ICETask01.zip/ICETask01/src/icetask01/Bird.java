/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask01;

/**
 *
 * @author lab_services_student
 */
public class Bird extends Animal{
    
    //variables
    int colour;
    
    //getters and setters
    public String getColour()
    {
        if (this.colour == 1) 
        {
            return "grey";
        }
        else
            if (this.colour == 2) 
            {
                return "white";
            }
        else
                {
                  return "black";
                }
                
    }
    
    public void setColor(int colour)
    {
        this.colour = colour;
    }
    
    @Override
     public int getIDtag() {
        return IDtag;
    }

    @Override
    public void setIDtag(int IDtag) {
        this.IDtag = IDtag;
    }

    @Override
    public String getSpecies() {
        return species;
    }

    @Override
    public void setSpecies(String species) {
        this.species = species;
    }
   
    
    public Bird(int IDtag, String species, int colour)
    {
        super(IDtag, species);
        this.colour = colour;
    }
    
}
