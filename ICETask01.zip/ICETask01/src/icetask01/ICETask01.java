/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask01;

/**
 *
 * @author lab_services_student
 */
public class ICETask01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
         Bird brd;
         Reptile rept;
         
         brd = new Bird(001, "Eagle", 2);
         rept = new Reptile(002, "Snake", 20.3);
         
         System.out.println("---Bird---");
         
         System.out.println("ID Tag: " + brd.getIDtag());
         System.out.println("Specie: " + brd.getSpecies());
         System.out.println("Colour: " + brd.getColour());
         
         System.out.println("\n---Reptile---");
         
         System.out.println("ID Tag: " + rept.getIDtag());
         System.out.println("Specie: " + rept.getSpecies());
         System.out.println("Blood Temperture: " + rept.getBloodTemp());
        
    }
    
}
