/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask01;

/**
 *
 * @author lab_services_student
 */
public class Animal {
    
    //variables
     int IDtag;
     String species;

    
    //getter and setter
    public int getIDtag() {
        return IDtag;
    }

    public void setIDtag(int IDtag) {
        this.IDtag = IDtag;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
    
    public Animal(int IDtag, String species)
    {
        this.IDtag = IDtag;
        this.species = species;
    }
    
    
    
    
}
